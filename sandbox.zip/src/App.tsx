import { useState } from "react";
import "./App.css";

const-phrases = [
  "No",
  "Estas segura?",
  "Piensalo bien minion",
  "Andalee",
  "Di que siii",
  "pofisss",
  "Yo se que quieress ;)",
  ;)

function App() {
  const [count, setCount] = useState(0);
  const [yesPressed, setyespressed] = useState(false);
  const yesButtonsize = noCount * 20 + 16;

  function handleNoclick() {
    setNocount(noCount + 1);
  }

  function getNoButtontext() {
    return phrases [Math.min(noCount, phrases.lenght - 1)];
  }

  return (
    <div className="Mi Novia-Minion">
      {yesPressed ? ()}     
    <>
      <img
        alt="Dame un besotote"
        src="https://media.tenor.com/gUiu1zyxfzYAAAAi/bear-kiss-bear-kisses.com"
        />
        <div className="text">Yay!!!!</div>
        </>
      ) : (
        <>
          <img
            alt="bear with hearts"
            src="https://giftdb.com/images/high/cute-love-bear-roses-ou7zho5oosxnp.gift"
            />

            <div>Quieres ser mi linda mujer para toda la vida?</div>
            <div>
              <button
                className="yesButton"
                style={{ fontSize: yesButtonSize}}
                onClick={() => setYesPressed(true)}
                >
                  Si
                </button>
                <button onClick={handleNoclick} className="noButton">
                  {getNoButtonText()}
                </button>
               </div>
              </>
            )}
            </div>
        );
      }
export default app;